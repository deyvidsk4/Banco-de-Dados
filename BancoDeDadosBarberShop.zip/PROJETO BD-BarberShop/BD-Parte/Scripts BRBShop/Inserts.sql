USE BARBERSHOP

-- INSERINDO VALORES DA TABELA CLIENTE 

INSERT INTO CLIENTE(RG_CLIENTE, CPF_CLIENTE, NOME_CLIENTE, DT_NASC_CLIENTE, TELEFONE_CLIENTE, ENDERECO_CLIENTE, E_MAIL_CLIENTE, DT_CADASTRO)
  VALUES ('46145755','55108279205','Vinicius Anthony da Silva','1997-01-01','95984208095','PE, Camaragibe, Bairro Novo do Carmelo, 945, Rua Santa Maria, 54762-374','viniciusanthonydasilva-94@sectron.com.br','2018-06-16'),
               ('45246854','25465465803','Jonas Claudino da Silva','1998-02-02','81986058456','PE, Recife, San Martin, 592, Rua Tanguar�, 50820-050','jonasclaudino214@gmail.com','2019-05-12'),
			   ('44265658','25265886404','Deyvid Jose Lima dos Santos','2000-03-13','81987456212','PE, Jaboat�o dos Guararapes, Santana, 629, Rua Rigel, 54160-503','deyvidsantos345@hotmail.com','2012-12-02'),
			   ('43564568','32545824505','Lucas Ferreira dos Santos','2000-04-05','81984575847','PE, Caruaru, Maur�cio de Nassau, 813, Avenida S�o Patr�cio, 55014-267','lucasferreira12@gmail.com','2016-02-10'),
			   ('45659587','25442132504','Jo�o Luiz Ferreira Filho','1998-05-03','81984756212','PE, Petrolina, Ant�nio Cassimiro, 232, Rua Tr�s, 56319-600','joaolucas12@hotmail.com','2018-08-05'),
			   ('25654582','25432525402','Rafael de Souza','1997-06-12','81987956589','PE, Paulista, Nossa Senhora da Concei��o, 677, Rua Sete, 53429-470','rafaelsouza13@hotmail.com','2016-09-15'),
			   ('32589987','26468943209','Carlos Augusto de Souza','1989-09-15','81989549874','PE, Recife, Boa Vista, 713, Vila Sete de Setembro','carlosaugusto45@gmail.com','2018-05-30'),
			   ('35287213','22665732102','Jos� Fernando dos Santos','1977-10-12','81987562514','PE, Caruaru, Nova Caruaru, 648, Avenida Jo�o Soares de Lira, 55014-615','josefernando36@hotmail.com','2015-09-28'),
			   ('25659234','25732735401','Alex de Souza Filho','1988-11-06','81987592546','PE, Recife, Bras�lia Teimosa, 575, Rua Lup�rcio, 51010-720','alexsouza123@hotmail.com','2018-08-07'),
			   ('46875415','26465915405','Pedro Ferreira de Souza','1965-12-13','81987562541','PE, Camaragibe, Vila da F�brica, 946, Travessa Galv�o Raposo, 54756-069','pedroferreira254@gmail.com','2015-05-16')

-- INSERINDO VALORES DA TABELA FUNCIONARIO
INSERT INTO FUNCIONARIO(RG_FUNC,NOME_FUNC,TELEFONE_FUNC,E_MAIL_FUNC,DT_ADMISSAO,CARGO,SALARIO,CPF_FUNC,DT_NASC_FUNC,ENDERECO_FUNC, CTPS)
VALUES ('10684544','Jo�o Horlando da Silva','81983652451','joaoHorlando159@hotmail.com','2018-05-04','Atendente','1200','06921525601','1989-12-05','PE, S�o Louren�o da Mata, Pixete, 192, Rua Erm�rio Gomes da Silva, 54250-602','5809542'),
             ('15012658','Cesar Augusto Ferreira Filho','81987594569','Cesaraugusto154@gmail.com','2018-04-05','Cabeleireiro','1500','05424525412','1995-12-05','PE, Cabo de Santo Agostinho, Malaquias, 151, Rua Quatro, 50741-710','0256359'),
			 ('12254654','Junior Lima dos Santos','81987541658','Juniorsantos45@gmail.com','2018-06-14','Cabeleireiro','1500','04525468502','1987-12-05','PE, Paulista, Jardim Maranguape, 263, Rua Cento e Quatro, 55019-250','3028657'),
			 ('45521659','Sidraque Agostinho Carrara','81987549856','Sidraqueagostinho@hotmai.com','2009-02-15','Administrador','2000,','02565452105','1977-02-16','PE, Cabo de Santo Agostinho, Paiva, 302, Alameda dos Coqueirais, 54756-580','0352648'),
			 ('10524589','Alaci ferreira dos Santos','81987456549','Alaciferreira16@gmail.com','2011-04-05','Cabeleireiro','1500','25432554520','1985-12-11','PE, Olinda, Peixinhos, 700, Rua Greg�rio Bezerra, 54310-275','3650238')
			
-- INSERINDO VALORES DA TABELA FORNECEDOR
INSERT INTO FORNECEDOR(CNPJ_FORNECEDOR,TIPO_FORNECEDOR,NOME_FORNECEDOR,TELEFONE_FORNECEDOR,E_MAIL_FORNECEDOR,ENDERECO_FORNECEDOR)
VALUES ('51039370000173','Monopolista','Coca-Cola','8139609636','cocacolape66@hotmail.com','PE, Abreu e Lima, Fosfato, 201, 4� Travessa Jos� Bonif�cio, 53580-594'),
             ('62988318000180','Monopolista','Heineken','8136423966','heinekenpe@outlook.com.br','PE, Jaboat�o dos Guararapes, Cajueiro Seco, 844, Rua Asa Branca, 54330-115'),
			 ('94098507000173','Monopolista','Indai�','8129397922','indaiaaguamineral@hotmail.com','PE, Arcoverde, Boa Vista, 404, Vila S�o Jos�, 56519-401'),
			 ('49394928000197','Monopolista','Ambev','8127529489','ambevcervejas000_@gmail.com','PE, S�o Louren�o da Mata, Penedo, 947, Rua F�lix Peixoto, 54715-250'),
			 ('65015532000148','Monopolista','Johnnie Walker','8135295059','johnniewalker855@gmail.com.br','PE, Paulista, Jaguarana, 431, Rua Subida da Urub�, 53419-310')
	
-- INSERINDO VALORES DA TABELA PRODUTO
INSERT INTO PRODUTO(NOME_PROD, PRECO_PROD, TIPO_PROD, VALIDADE_PROD, ESTOQUE_PROD, CATEGORIA_PROD)
 VALUES('Coca-Cola Lata 350ml','4','Refrigerante','2022-12-20','60','Bebida'),
             ('Coca-Cola 1l','5.3','Refrigerante','2021-10-30','55','Bebida'),
			 ('Coca-Cola 2l','7.5','Refrigerante','2022-11-23','40','Bebida'),
             ('Fanta Lata 350ml','3.50','Refrigerante','2019-05-26','56','Bebida'),
			 ('Fanta 1l','4.5','Refrigerante','2019-02-16','35','Bebida'),
			 ('Fanta 2l','6.5','Refrigerante','2019-04-25','42','Bebida'),
			 ('�gua','3','�gua Mineral','2023-03-28','44','Bebida'),
			 ('�gua','2.5','�gua G�s','2022-04-30','50','Bebida'),
			 ('Heineken Lata 250ml','3.9','Cerveja','2022-10-27','65','Bebida Alco�lica'),
			 ('Heineken Lata 350ml','4.9','Cerveja','2022-11-24','70','Bebida Alco�lica'),
			 ('Heineken Long Neck 250ml','4','Cerveja','2021-10-21','62','Bebida Alco�lica'),
			 ('Devassa Lata 250ml','3','Cerveja','2020-02-28','70','Bebida Alco�lica'),
			 ('Devassa Loura Premium 355ml','4.20','Cerveja','2020-03-12','55','Bebida Alco�lica'),
			 ('Budweiser Lata 350ml','3.39','Cerveja','2022-03-22','66','Bebida Alco�lica'),
			 ('Budweiser 5,90ml','5.90','Cerveja','2022-05-30','72','Bebida Alco�lica'),
			 ('Red Label 1l','90','Whisky','2024-06-25','80','Bebida Alco�lica'),
			 ('Black Label 1l','120','Whisky','2024-07-30','73','Bebida Alco�lica')

-- INSERINDO VALORES DA TABELA AGENDAMENTO
INSERT INTO AGENDAMENTO(DATA_AGENDAMENTO, HORA_AGENDAMENTO, STATUS_AGENDAMENTO)
 VALUES('2019-02-24','13:40','Aguardando' ),
               ('2018-10-10','13:30','Realizado'),
			   ('2018-11-02','14:30','Realizado'),
			   ('2019-10-20','14:00','Aguardando'),
			   ('2020-04-02','15:30','Aguardando'),
			  ('2018-11-13','19:50','Realizado'),
			  ('2019-05-18','15:00','Cancelado'),
			  ('2019-11-06','18:20','Remarcado(Aguardando)'),
			  ('2018-05-06','19:00','Realizado'),
			  ('2018-12-07','15:45','Aguardando')

-- INSERINDO VALORES DA TABELA GOSTO_MUSICAL_CLIENTE
INSERT INTO GOSTO_MUSICAL_CLIENTE(PLAYLIST_CLIENTE)
 VALUES('Rock'),
             ('Pop'),
			 ('Eletronica'),
			 ('Sertanejo'),
			 ('MPB'),
			 ('Pagode'),
			 ('Samba'),
			 ('Funk'),
			 ('Rap'),
			 ('Brega'),
			 ('Gospel'),
			 ('Ax�'),
			 ('R&B'),
			 ('Punk'),
			 ('Forr�')

-- INSERINDO VALORES DA TABELA SERVICO
INSERT INTO SERVICO(DATA_ATENDIMENTO, HORA_ATENDIMENTO)
VALUES ('2018-10-10','13:30'),
               ('2018-11-02','14:30'),
               ('2018-11-13','19:50'),
			   ('2018-05-06','19:00')
			  



-- INSERINDO VALORES DA TABELA TIPO_SERVICO
INSERT INTO TIPO_SERVICO(PRECO_SERVICO, DESCRICAO)
 VALUES('40',' Sidecut  e Cavanhaque'),
             ('45','Moicano com Degrad� e Cavanhaque'),
			 ('45','Degrad� e Bigode'),
			 ('45','Degrad� e Full beard'),
			 ('30','Militar e Bigode'),
			 ('35','Corte Caesar e Full Beard'),
			 ('40','Undercut e Old Dutch'),
			 ('45',' Coque Samurai e Full Beard'),
			 ('35','Surfista e Cavanhaque')

-- INSERINDO VALORES DA TABELA FORMA_PGTO
INSERT INTO FORMA_PGTO(DESCRICAO)
 VALUES('Cr�dito'),
               ('D�bito'),
			   ('D�bito'),
			   ('Dinheiro'),
			   ('Dinheiro'),
			   ('Cr�dito'),
			   ('Dinheiro'),
			   ('Dinheiro'),
			   ('D�bito')