-- PROCEDURE PARA CADASTRAR, ALTERAR E DELETAR CLIENTE
CREATE PROCEDURE SP_MANTER_CLIENTE
        @Acao int , 
		@IDCliente int = null,
		@Nome varchar (100) = null,
		@RGCliente char (8),
		@CPFCliente char (11),
		@DTNascCliente date,
		@TelefoneCliente char (11),
		@EnderecoCliente varchar (500),
		@EmailCliente varchar (100)
AS
BEGIN
        
		IF (@Acao = 0)
		BEGIN 
		     DELETE FROM CLIENTE
			 WHERE ID_CLIENTE = @IDCliente

			 PRINT 'UM CLIENTE FOI DELETADO DO SISTEMA'

			 SELECT @IDCliente AS RETORNO
		END
		ELSE IF (@Acao = 1)
		BEGIN
		     INSERT INTO CLIENTE(NOME_CLIENTE, RG_CLIENTE, CPF_CLIENTE, DT_NASC_CLIENTE, TELEFONE_CLIENTE, ENDERECO_CLIENTE, E_MAIL_CLIENTE, DT_CADASTRO)
			 VALUES (@Nome, @RGCliente, @CPFCliente, @DTNascCliente, @TelefoneCliente, @EnderecoCliente, @EmailCliente, GETDATE())

			 PRINT 'UM CLIENTE FOI CADASTRADO NO SISTEMA! '

			 SELECT SCOPE_IDENTITY() AS RETORNO
		END
		ELSE IF (@Acao = 2)
		BEGIN
		     UPDATE CLIENTE
			 SET NOME_CLIENTE = @Nome, RG_CLIENTE = @RGCliente, CPF_CLIENTE = @CPFCliente, DT_NASC_CLIENTE = @DTNascCliente, TELEFONE_CLIENTE = @TelefoneCliente, ENDERECO_CLIENTE = @EnderecoCliente, E_MAIL_CLIENTE = @EmailCliente
			 WHERE ID_CLIENTE = @IDCliente

			  PRINT 'FOI FEITA UMA ALTERA��O NA TABELA CLIENTE DO SISTEMA! '

			 SELECT @IDCliente AS RETORNO
		END
		ELSE
		BEGIN
		     RAISERROR ('A��o n�o implementada', 14, 1)
        END

END

-- EXECUTANDO STORE PROCEDURE
EXEC SP_MANTER_CLIENTE 1, NULL, 'Miguel Maximiano da S�lva', '70110872','95212506538','1990-01-05','81988608173','PE, Jaboat�o dos Guararapes,  Cajueiro Seco, 23, Rua juriti  54340-080','maximiano155_@gmail.com.br'  


--PROCEDURE PARA AGENDAMENTO

CREATE PROCEDURE SP_AGENDAR
@Acao int,
@IDAgendamento int = null,
@DataAgendamento date,
@HoraAgendamento time
AS
BEGIN
        IF (@Acao = 0)
		BEGIN
		     DELETE FROM AGENDAMENTO
			 WHERE ID_AGENDAMENTO = @IDAgendamento

			 SELECT @IDAgendamento AS AGENDADO
			 END
		ELSE IF (@Acao = 1)
		BEGIN
		     INSERT INTO AGENDAMENTO (DATA_AGENDAMENTO, HORA_AGENDAMENTO)
			 VALUES (@DataAgendamento, @HoraAgendamento)

			  SELECT SCOPE_IDENTITY() AS AGENDADO
			  END
		ELSE IF (@Acao = 2)
		BEGIN
		     UPDATE AGENDAMENTO
			 SET DATA_AGENDAMENTO = @DataAgendamento, HORA_AGENDAMENTO = @HoraAgendamento
			 WHERE ID_AGENDAMENTO = @IDAgendamento

			 SELECT @IDAgendamento AS AGENDADO
		END
		ELSE
		BEGIN
		     RAISERROR ('A��o n�o implementada', 14, 1)
        END

END

---- EXECUTANDO STORE PROCEDURES
EXEC SP_AGENDAR 1, NULL, '2018-12-16', '14:20'



